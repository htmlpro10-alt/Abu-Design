// Centralized asset exports with zero-broken-image fallbacks
import heroStudio from './../assets/images/hero_studio_craft_1791187517878.jpg';
import packagingBoxes from './../assets/images/portfolio_branding_boxes_1791187544825.jpg';
import signage3D from './../assets/images/portfolio_3d_signage_1791187560696.jpg';
import stationerySet from './../assets/images/portfolio_stationery_set_1791187573083.jpg';
import printPress from './../assets/images/craft_print_press_1791187585994.jpg';

export const ASSETS = {
  hero: heroStudio,
  packaging: packagingBoxes,
  signage: signage3D,
  stationery: stationerySet,
  press: printPress,
};
